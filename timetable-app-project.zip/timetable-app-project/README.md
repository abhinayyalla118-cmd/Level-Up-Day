# Timetable App — APK build (no Android Studio needed)

Ee folder ni GitHub ki upload chesthe, GitHub free ga (cloud lo) mee APK ni build chesi istundi.
Mee laptop lo Android Studio kani, Android SDK kani, emi download cheyalsina avasaram ledu.

## Steps

1. github.com lo free account create cheskondi (already unte skip).
2. New repository create cheyandi (Public or Private, either works) — e.g. name: `timetable-app`.
3. Repo create chesaka, "Add file" -> "Upload files" button click chesi, ee folder lo unna
   anni files & folders (`package.json`, `capacitor.config.json`, `www` folder, `.github` folder)
   anni oke sari select chesi upload cheyandi. (Zip ni first extract chesi, andulo unna files
   ni upload cheyandi — zip file ni direct ga upload cheyakandi.)
4. "Commit changes" click cheyandi.
5. Repo lo top menu lo **Actions** tab ki వెళ్ళండి. "Build Android APK" ane workflow
   automatic గా start avuthundi (2-4 nimishalu padutundi).
   Start avvakapothe, workflow పేరు మీద click chesi, కుడివైపు "Run workflow" button
   click cheyandi.
6. Build complete (green tick ✅) ayyaka, aa run open chesi, కింద "Artifacts" section
   lo **timetable-app-apk** ane zip file kanipistundi — దాన్ని download cheyandi.
7. Aa zip lo `app-debug.apk` untundi. Danini phone ki (USB / Drive / WhatsApp / email
   whatever) transfer chesi, phone Settings lo "Install unknown apps" permission ichi,
   install cheskondi.
8. App open chesaka, "Alerts" page lo "Enable notifications" button nokandi — ఇది
   అలారంలు screen-off లో కూడా మోగడానికి permission తీసుకుంటుంది.

## Notes
- Free GitHub account ki ee build minutes ki charge undadu (public repo aithe unlimited,
  private repo aithe kuda nela ki chala free minutes untayi, ee chinna build vatiki
  chalinanni).
- App name / package id maarchali ante `capacitor.config.json` lo `appId` mariyu
  `appName` maarchandi (build cheyakamunde).
- Prathi sari `www/index.html` update chesinappudu, malli GitHub ki upload chesi commit
  cheste, Actions automatic ga malli build chesi kotha APK istundi.
